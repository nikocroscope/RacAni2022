﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiceCheckZoneScript : MonoBehaviour {

	Vector3 diceVelocity;
	[SerializeField] private Animator myDancer;
	[SerializeField] private Animator myDancer2;
	[SerializeField] private Animator myDancer3;
	[SerializeField] private Animator myDancer4;
	[SerializeField] private string dance1 = "Dance1";
	[SerializeField] private string dance2 = "Dance2";
	[SerializeField] private string dance3 = "Dance3";
	[SerializeField] private string dance4 = "Dance4";
	[SerializeField] private string dance5 = "Dance5";
	[SerializeField] private string dance6 = "Dance6";

	// Update is called once per frame
	void FixedUpdate () {
		diceVelocity = DiceScript.diceVelocity;
	}

	void OnTriggerStay(Collider col)
	{
		if (diceVelocity.x == 0f && diceVelocity.y == 0f && diceVelocity.z == 0f)
		{
			switch (col.gameObject.name) {
			case "side1":
				DiceNumberTextScript.diceNumber = 6;
				myDancer.Play(dance6);
					myDancer2.Play(dance6);
					myDancer3.Play(dance6);
					myDancer4.Play(dance6);
					break;
			case "side2":
				DiceNumberTextScript.diceNumber = 5;
				myDancer.Play(dance5);
					myDancer2.Play(dance5);
					myDancer3.Play(dance5);
					myDancer4.Play(dance5);
					break;
			case "side3":
				DiceNumberTextScript.diceNumber = 4;
				myDancer.Play(dance4);
					myDancer2.Play(dance4);
					myDancer3.Play(dance4);
					myDancer4.Play(dance4);
					break;
			case "side4":
				DiceNumberTextScript.diceNumber = 3;
				myDancer.Play(dance3);
					myDancer2.Play(dance3);
					myDancer3.Play(dance3);
					myDancer4.Play(dance3);
					break;
			case "side5":
				DiceNumberTextScript.diceNumber = 2;
				myDancer.Play(dance2);
					myDancer2.Play(dance2);
					myDancer3.Play(dance2);
					myDancer4.Play(dance2);
					break;
			case "side6":
				DiceNumberTextScript.diceNumber = 1;
				myDancer.Play(dance1);
					myDancer2.Play(dance1);
					myDancer3.Play(dance1);
					myDancer4.Play(dance1);
					break;
			}
		}
	}
}
